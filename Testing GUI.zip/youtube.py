from pytube import YouTube

from moviepy.editor import *
# YouTube video URL
youtube_url = "https://www.youtube.com/watch?v=m_6WnQCbJRQ"

# Output directory where the video will be saved
output_directory = "./"

# Create a YouTube object
yt = YouTube(youtube_url)

# Choose the stream with the desired resolution and file format
# For example, we'll select the highest resolution stream with mp4 format
video_stream = yt.streams.filter(progressive=True, file_extension="mp4").get_highest_resolution()

# Download the video
video_stream.download(output_path=output_directory)

print(f"Video downloaded and saved as {output_directory + yt.title}.mp4")



# Input MP4 video file path
input_mp4_file=output_directory + yt.title+".mp4"

# Output WAV audio file path
output_wav_file = output_directory + yt.title+".wav"

# Load the MP4 video
video_clip = VideoFileClip(input_mp4_file)

# Extract the audio from the video and save it as WAV
audio_clip = video_clip.audio
audio_clip.write_audiofile(output_wav_file)

# Close the video and audio clips
video_clip.close()
audio_clip.close()

# Delete the original MP4 file
import os
#os.remove(input_mp4_file)

print(f"MP4 video converted to WAV audio and original MP4 file deleted.")
