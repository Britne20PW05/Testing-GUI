import csv
import io
import os
import threading
import time
import wave
from datetime import datetime
from pathlib import Path
from struct import unpack
import PySimpleGUI as sg
import numpy as np
import pandas as pd
import pyaudio
import scipy.io.wavfile as wav
import scipy.signal as signal
import tensorflow as tf
import vlc
from moviepy.audio.io.AudioFileClip import AudioFileClip
from pydub import AudioSegment
from moviepy.editor import VideoFileClip

'''
global file
file = "mixed_37sec"'''

interpreter = tf.lite.Interpreter('lite-model.tflite')
input_details = interpreter.get_input_details()
waveform_input_index = input_details[0]['index']
output_details = interpreter.get_output_details()
scores_output_index = output_details[0]['index']


# embeddings_output_index = output_details[1]['index']
# spectrogram_output_index = output_details[2]['index']


def class_names_from_csv(class_map_csv_text):
    """Returns list of class names corresponding to score vector."""
    class_map_csv = io.StringIO(class_map_csv_text)
    class_names = [display_name for (class_index, mid, display_name) in csv.reader(class_map_csv)]
    class_names = class_names[1:]  # Skip CSV header
    return class_names


class AudioFile:

    def __init__(self):

        """ Init audio stream """
        '''self.wf = wave.open(file, 'rb')
        self.p = pyaudio.PyAudio()
        self.stream = self.p.open(
            format=self.p.get_format_from_width(self.wf.getsampwidth()),
            channels=self.wf.getnchannels(),
            rate=self.wf.getframerate(),
            output=True
            )
        '''

    def play(self):
        # wavefile = wave.open(file + ".wav", 'r')
        '''wf = wave.open("testing.wav")
        sample_rate, audio = wav.read("testing.wav")'''

        # length = wf.getnframes()
        target_sr1 = 16000

        global elements
        one = 1
        count = 0
        v = 0
        start = 0
        end = 1

        while True:
            try:
                #datasplit = audio[start:end]
                videox = VideoFileClip(video).subclip(start, end)
                datasplit1 = videox.audio.to_soundarray()
                datasplit = datasplit1[:, 0]
                start += 1
                end += 1

                # data = unpack('h' * (len(data) // 2), data)

                len1 = len(datasplit)
                resampled_audio1 = signal.resample(datasplit, int(len(datasplit) * target_sr1 / sample_rate))
                resampled_audio1 = resampled_audio1.astype(datasplit1.dtype)
                data = resampled_audio1

                # waveform = np.frombuffer(data, dtype=np.int16) / 32767
                waveform1 = data.astype(np.float32)

                ''' Spectogram '''
                '''spectrogram = tf.signal.stft(waveform1, frame_length=255, frame_step=128)
                spectrogram = tf.abs(spectrogram)
                spectrogram = spectrogram[..., tf.newaxis]
                x = spectrogram
                waveform1 = x[tf.newaxis, ...]'''
                ''' Spectogram '''

                interpreter.resize_tensor_input(waveform_input_index, [len(waveform1)], strict=False)
                interpreter.allocate_tensors()
                interpreter.set_tensor(waveform_input_index, waveform1)
                interpreter.invoke()

                '''scores, embeddings, spectrogram = (
                    interpreter.get_tensor(scores_output_index), interpreter.get_tensor(embeddings_output_index),
                    interpreter.get_tensor(spectrogram_output_index))'''
                scores = interpreter.get_tensor(scores_output_index)

                # print(scores.mean(axis=0).argmax())
                # class_names = class_names_from_csv(open('yamnet_modified_final.csv').read())
                class_names = class_names_from_csv(open('yamnet_class_map.csv').read())
                #class_names = class_names_from_csv(open('csv_data_final.csv').read())
                elements = (class_names[scores.mean(axis=0).argmax()])
                '''x_labels = ['fight', 'music', 'silence', 'speech']  #demo_model & asc+yam_mdl
                # x_labels = ['music', 'speech', 'vehicle']  # yamnet dataset model
                label_pred = np.argmax(scores, axis=1)
                command = x_labels[label_pred[0]]'''
                print(elements)

                if one == 1:
                    player.play()
                    time.sleep(0.3)
                    # oldnow = datetime.now()
                    one = 2

                oldnow = datetime.now()
                oldcurrent_time = oldnow.strftime("%S")

                while 1:
                    now = datetime.now()
                    current_time = now.strftime("%S")
                    # print(current_time)
                    if abs(int(current_time) - int(oldcurrent_time)) >= 1:
                        window['-TEXT-'].update(elements)
                        window['-COUNT-'].update(count)
                        count += 1
                        # print(elements)
                        # print(current_time)
                        break

            except:
                print("END")
                break


if __name__ == "__main__":
    '''GUI PROCESS CODE'''
    Instance = vlc.Instance()
    player = Instance.media_player_new()

    sg.theme("DarkBlue")

    layout = [
        [sg.Text('file', enable_events=True,
                 key='-fname-', font=('Arial Bold', 18),
                 expand_x=True, justification='center')],
        [sg.Input(key='-IN-', visible=False, enable_events=True),
         sg.FileBrowse('CHOOSE AUDIO', file_types=(("MP4 Files", "*.mp4"),))],
        [sg.Text('AUDIO SCENE CLASSIFICATION', enable_events=True,
                 key='-TEXT-', font=('Arial Bold', 18),
                 expand_x=True, justification='center')],
        [sg.Text('COUNT', enable_events=True,
                 key='-COUNT-', font=('Arial Bold', 14),
                 expand_x=True)],
        [sg.Graph((640, 480), (0, 0), (640, 480), key='-CANVAS-')]
    ]
    window = sg.Window('SCENE DETECTION MODEL', layout, finalize=True)

    video_panel = window['-CANVAS-'].Widget.master
    # set the window id where to render VLC's video output
    h = video_panel.winfo_id()  # .winfo_visualid()?
    player.set_hwnd(h)

    while True:
        event, values = window.read()
        video = str(values[event])

        file_path_components = video.split('/')
        file_name_and_extension = file_path_components[-1].rsplit('.', 1)
        window['-fname-'].update(file_name_and_extension)
        print(file_name_and_extension)

        videox = VideoFileClip(video)
        #audio_frames = videox.audio.to_soundarray()

        sample_rate = videox.audio.fps

        #audio = audio_frames[:, 0]

        m = Instance.media_new(str(video))
        player.set_media(m)
        a = AudioFile()
        t1 = threading.Thread(target=a.play)
        t1.start()

        # event = threading.Event()
        # threading.Thread(target=video_play, args=(event,)).start()

        # threading.Thread(target=a.play(), args=(event,)).start()
